VHDL_Code : contains only the necessary files of the project.
	Open ES_mini_project_TRDB_D5M_LT24.qpf in quartus folder and compile the project to get .sopinfo file and .sof file
	For modelsim simulation you need to create new project (it's path related :( ), and then include the files in modelsim folder
C_Code : create a new NIOS project, and then put the content of this folder in the created project folder 
ImageConverter : python utility to convert 320*240 png pictures to our custom image format binaries 