NEED PILLOW LIBRARY

(WIN+R easy_install Pillow)


bintopic.py

take a binary file (a frame as specified in report two RGB pixels per 32 bits word) 
convert it to a png pic
store the pic to the specified path and show it

pictobin.py

does the opposite, but don't show the pic